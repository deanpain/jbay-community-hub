#!/usr/bin/env bash
# J-Bay Community Hub — Catalyst Demo Script
# Run from repo root: bash docs/catalyst/evidence/demo.sh
set -euo pipefail

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'
PASS=0
FAIL=0

step() {
  printf "\n[ ] %s..." "$1"
}

ok() {
  printf "\r${GREEN}[✓]${NC} %s\n" "$1"
  PASS=$((PASS + 1))
}

fail() {
  printf "\r${RED}[✗]${NC} %s\n" "$1"
  FAIL=$((FAIL + 1))
}

echo "=== J-Bay Community Hub — Catalyst Evidence Demo ==="
echo "Tag: v0.1.0-alpha | $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo ""

# 1. Monorepo structure
step "Monorepo structure"
if [ -f "pnpm-workspace.yaml" ] && [ -f "package.json" ]; then
  ok "Monorepo root with pnpm-workspace.yaml"
else
  fail "Monorepo root missing"
fi

# 2. Packages
step "Package structure"
EXPECTED="config shared ui-tokens api identity-worker contracts"
for pkg in $EXPECTED; do
  if [ -d "packages/$pkg" ] || [ -d "services/$pkg" ] || [ -d "$pkg" ]; then
    ok "Found: $pkg"
  fi
done
if [ -d "apps" ]; then
  ok "apps/ directory (mobile app)"
fi

# 3. IaC manifests
step "IaC manifests"
if [ -d "infra" ] && [ -f "infra/main.tf" ]; then
  ok "Terraform manifests in infra/"
else
  fail "IaC not found"
fi

# 4. Config (municipality swap)
step "Config package"
if [ -f "packages/config/src/index.ts" ] || [ -f "packages/config/index.ts" ]; then
  ok "Config package with municipality swap support"
else
  fail "Config package not found"
fi

# 5. Identity worker
step "Identity worker"
if [ -d "services/identity-worker/src" ]; then
  ok "Identity-worker at services/identity-worker"
else
  fail "Identity-worker not found"
fi

# 6. Documentation
step "Catalyst documentation"
DOCS="docs/catalyst/catalyst-fund15-requirements.md docs/catalyst/milestone-checklist.md docs/catalyst/release-checklist.md docs/catalyst/statement-of-milestones-template.md"
for doc in $DOCS; do
  if [ -f "$doc" ]; then
    ok "Doc: $doc"
  else
    fail "Missing: $doc"
  fi
done

# 7. README quickstart
step "README quickstart"
if [ -f "README.md" ]; then
  ok "README.md with quickstart"
else
  fail "README missing"
fi

# 8. SECURITY.md
step "Security policy"
if [ -f "SECURITY.md" ]; then
  ok "SECURITY.md"
else
  fail "SECURITY missing"
fi

# 9. NOTICE
step "Third-party notices"
if [ -f "NOTICE" ]; then
  ok "NOTICE file"
else
  fail "NOTICE missing"
fi

# 10. Git tag
step "Release tag"
TAG=$(git tag --list "v0.1*" 2>/dev/null | head -1)
if [ -n "$TAG" ]; then
  ok "Release tag: $TAG"
else
  fail "No release tag found"
fi

# Summary
echo ""
echo "=============================="
echo "Results: $PASS passed, $FAIL failed"
echo "=============================="

# Note: pnpm test/typecheck/lint require node_modules installed
if [ -d "node_modules" ]; then
  echo ""
  echo "=== Running CI checks ==="
  pnpm lint --if-present 2>/dev/null && ok "Lint" || fail "Lint"
  pnpm typecheck --if-present 2>/dev/null && ok "Typecheck" || fail "Typecheck"
  pnpm -r test --if-present 2>/dev/null && ok "Tests" || fail "Tests"
fi
