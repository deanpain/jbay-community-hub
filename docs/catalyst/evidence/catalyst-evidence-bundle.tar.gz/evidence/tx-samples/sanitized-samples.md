# Sanitized Transaction Samples — J-Bay Community Hub

These are **anonymized** test transactions from the identity-worker batch processing pipeline. Real production data is confidential and not included in this open-source evidence bundle.

## Identity Worker — Batch Submission

```json
// POST /api/identity/batch — Sanitized test payload
{
  "batchId": "test-batch-001",
  "applicants": [
    {
      "applicantRef": "APP-00001",
      "idNumber": "XXXXXX XXXXX XX X XX",
      "fullName": "J DOE",
      "dateOfBirth": "1990-01-01"
    },
    {
      "applicantRef": "APP-00002",
      "idNumber": "XXXXXX XXXXX XX X XX",
      "fullName": "M SMITH",
      "dateOfBirth": "1985-06-15"
    }
  ],
  "verificationProvider": "sandbox",
  "callbackUrl": "https://api.example.com/webhooks/verification"
}
```

## Smart Contract — Community Treasury (Testnet)

```json
// Midnight Compact testnet — NIGHT token transfer
{
  "txHash": "0xabcd...1234",
  "from": "addr_test1...xxxx",
  "to": "addr_test1...yyyy",
  "value": "1000 NIGHT",
  "network": "midnight-testnet",
  "timestamp": "2026-04-15T10:30:00Z",
  "note": "Community grant disbursement — test"
}
```

## Verified Credential Issuance (Test)

```json
// VC issued via Identus sandbox
{
  "credentialId": "vc-001-test",
  "type": ["VerifiableCredential", "IdentityCredential"],
  "issuer": "did:prism:testnet:...",
  "subject": "did:prism:testnet:...",
  "credentialSubject": {
    "fullName": "J DOE",
    "idVerified": true,
    "verificationDate": "2026-04-20"
  },
  "proof": {
    "type": "Ed25519Signature2020",
    "created": "2026-04-20T14:00:00Z"
  }
}
```

## Notes

- All PII replaced with placeholders (XXXXXX/"xxx")
- Real batch submissions go through Altron DHA gateway behind Render
- Contract transactions use Midnight testnet (not mainnet)
- Full prod transaction history stored in secure vault (not in repo)
