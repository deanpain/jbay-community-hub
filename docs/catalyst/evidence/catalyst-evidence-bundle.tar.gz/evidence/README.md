# Catalyst Fund 15 — Grant Evidence Bundle

**Project:** J-Bay Community Hub (Midnight Compact DApps)
**Date:** 2026-05-07
**Tag:** v0.1.0-alpha
**Prepared by:** Major (CEO)

## Contents

| Item | Location | Status |
|------|----------|--------|
| **Screenshots** | `screenshots/` dir below | See individual notes |
| **Transaction samples** | `tx-samples/` | Sanitized test data |
| **Repo tag** | `git tag v0.1.0-alpha` | Published to GitHub |
| **Demo script** | `demo.sh` below | Verified |
| **Release checklist** | `../release-checklist.md` | 7/11 complete |
| **Milestone checklist** | `../milestone-checklist.md` | Updated |
| **QA matrix** | `../qa-matrix.md` | Signed-off |
| **SoM template** | `../statement-of-milestones-template.md` | Tailored |
| **IaC manifests** | `../../infra/` | dev/staging/prod |

## Quick Links

- [GitHub tag v0.1.0-alpha](https://github.com/deanpain/jbay-community-hub/releases/tag/v0.1.0-alpha)
- [Identity-worker on Render](https://dashboard.render.com/...) — [human] link
- [Mobile app on TestFlight](https://testflight.apple.com/...) — [human] link
- [Deployed staging](https://jbay-community-hub-staging.vercel.app) — [human] link

## Verification Script

Run `bash demo.sh` from repo root to verify the core pipeline:
1. Lint & typecheck pass
2. Unit tests pass (shared + identity-worker)
3. Contract tests pass
4. IaC plan validates (requires Terraform/OpenTofu installed)
